<?php

namespace BotMan\BotMan\Interfaces;

interface QuestionActionInterface
{
    /**
     * Array representation of the question action.
     *
     * @return array
     */
    public function toArray();
}
