<div class="inicio-content">
	<select id="busca-por" class="form-control" data-show-icon="true">
		<option value="2">Todos </option>
		<option data-subtext="<i class='fas fa-female'></i>" value="0">Mulheres</option>
		<option value="1">Homens</option>
	</select>



	<div class="users" id="users">

	</div>
</div>