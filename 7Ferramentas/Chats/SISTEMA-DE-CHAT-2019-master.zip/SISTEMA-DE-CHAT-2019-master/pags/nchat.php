<?php
	$chat = new chat($pdo);
	$chat->verifica_chat($explode['1']);
?>