# SISTEMA-DE-CHAT-2019
Estou trazendo um projeto que fiz de um sistema de chat utilizando php, ajax e pdo. 
Sistema totalmente funcional para chats em real time;


# Como configurar?
1º após baixar o projeto, abra o <b>index.php</b>, e procure por<br>
< base href="http://192.168.0.100/chat/"> ou localize a linha número <b>13</b> e troque o ### http://192.168.0.100/chat/ ### pelo url do seu site<br>

2º Importar o banco de dados <b>teste.sql</b> localizado na pasta <b>banco de dados</b>;<br>

3º Acessar o diretório <b>lib/dbconnect.php</b> e trocar os dados do banco atual para o seu;<br>

Após isso, seja feliz :)
