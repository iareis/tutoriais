<?php
	session_start();
	include_once("dbconnect.php");
	include_once("class.php");
?>